Thank you for your interest in Eight-Bit Madness. This font is intended to be hosted exclusively at https://www.dafont.com/8-bit-madness.font. The latest version should always be available at the mentioned URL.

As mentioned in the description, the font is free for personal use, but for commercial usage, please send me an email at tylerdunn998@gmail.com to discuss licensing options.